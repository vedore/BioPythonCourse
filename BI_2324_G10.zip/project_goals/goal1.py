import os
from Bio import SeqIO


## Metodo que através da atribuição de um endereço de um ficheiro fasta,
## o abre e dá print a todos os records presentes dentro do ficheiro, com 
## as suas respetivas descrições, ids e nomes, respetivamente. 
## Por fim dá print do numero de records existentes dentro do ficheiro
def get_details_about_records_from_fasta_files(genome_fasta_file):

    ## Inicialização de uma lista
    genome_record_list = []

    ## Abrimos o ficheiro com o metodo "with" para que no final
    ## o for loop, o ficheiro feche, a variavel "handle" é o 
    ## nome que atribuimos ao ficheiro
    with open(genome_fasta_file) as handle:

        ## for loop para correr todos os records presentes no ficheiro,
        ## O ficheiro é aberto através do metodo "SeqIO.parse" que nos dá
        ## um iterador com todos os records, como objetos "SeqRecords"
        ## a variavel "record" será um objeto "SeqRecord" do ficheiro
        for record in SeqIO.parse(handle, "fasta"):

            ## Print da descrição do record que se faz através do uso do atributo "description"
            print("Description: " + record.description)

            ## Print do id do record que se faz através do uso do atributo "id"
            print("Id: " + record.id)

            ## Print do nome do record que se faz através do uso do atributo "name"
            print("Name: " + record.name + "\n")

            ## A todos os records presentes no ficheiro são guardados numa lista já inicializada
            ## para que depois possam ser utilizados, caso se deseje
            genome_record_list.append(record)

    ## Dá se print do numero de records através do uso do método "len()" na lista "genome_record_list"
    ## o metodo "str()" é utilizado para passar a variavel de objeto "int" para um objeto "string"
    print("Number Of Records: " + str(len(genome_record_list)) + "\n")

    ## Devolve-se no final a lista com todos os records
    return genome_record_list

def main():

    ## Juntamos o metodo "os.path.abspath()" que nos irá dar a path absoluta de algum ficheiro, 
    ## com o metodo "os.path.join()" que irá através da junção da variavel "__file__" que é o 
    ## endereço do ficheiro que estamos a correr, neste caso, goal1.py, com uma expressão que 
    ## que irá subir duas directorias, resultando na path do trabalho "BIO".
    ## Depois concatamos a directoria que realmente queremos, neste caso, a pasta dos ficheiros fasta
    fasta_files_location = os.path.abspath(os.path.join(__file__, "../..")) + "\\fasta_files"

    ## Concactamos a diretoria com o ficheiro
    human_genome_fasta_file_location = fasta_files_location + "\\human_genome.fasta"
    corona_genome_fasta_file_location = fasta_files_location + "\\corona_genome.fasta"

    print("Details Of Human Genome File:\n")
    get_details_about_records_from_fasta_files(human_genome_fasta_file_location)
    print("Details Of Corona Genome File:\n")
    get_details_about_records_from_fasta_files(corona_genome_fasta_file_location)

    
## Para correr o metodo main, para que sejam apresentados os dados
main()