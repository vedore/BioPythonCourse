from datetime import datetime
from Bio import Entrez, Medline

Entrez.email = "fc56311@alunos.fc.ul.pt"

def search_pubmed_from_term(term):

    ## Entrez.esearch() initiates a search query using the Entrez module
    ## db="pubmed" specifies the database to search, which in this case is PubMed
    ## term=term assigns the search term to the variable term. This is the query used to search PubMed for relevant articles
    ## retmax="10" limits the number of search results returned to 10. This means it will only retrieve up to 10 articles that match the search query
    stream = Entrez.esearch(db="pubmed", term=term, sort="pubdate", retmax="10")

    ## Entrez.read() reads the results returned by the search query stored in stream
    ## It parses the results and stores them in the variable search_results. These results typically include PubMed IDs (PMIDs) of the articles that match the search criteria, among other information.
    search_results = Entrez.read(stream)

    ## Closes the Stream
    stream.close()

    ## Entrez.efetch() is used to retrieve records from the PubMed database
    ## db="pubmed" specifies the database from which to fetch records, in this case, PubMed
    ## id=search_results["IdList"] provides a list of PubMed IDs (PMIDs) obtained from the search results. This ensures that only records corresponding to these PMIDs are fetched
    ## rettype="medline" specifies the format of the records to be fetched as Medline format, which is a structured text format used for bibliographic data
    ## retmode="text" specifies the retrieval mode as text, indicating that the fetched records will be returned as plain text.
    stream = Entrez.efetch(db="pubmed", id=search_results["IdList"], rettype="medline", retmode="text")
    ## Medline.parse(stream) parses the fetched records from the stream using Biopython's Medline parser, and list() turns it into a list
    records = list(Medline.parse(stream))

    # Sort the records by date
    sorted_records = sorted(records, key=lambda x: x['DP'], reverse=True)

    for record in sorted_records:
        ## Retrieves the value of the "TI" (Title) field from a record obtained from PubMed search results.
        print("title:", record.get("TI", "?"))
        ## Retrieves the value of the "AU" (Authors) field from a record obtained from PubMed search results.
        print("authors:", record.get("AU", "?"))
        ## ## Retrieves the value of the "SO" (Source) field from a record obtained from PubMed search results.
        print("source:", record.get("SO", "?"))
        ## Retrieves the value of the "DP" (Data Publication) field from a record obtained from PubMed search results
        print("date:", record.get("DP", "?"))    
        print("")


def main():

    human_species = "Homo sapiens"
    corona_species = "coronavirus"

    print("Homo Sapiens Articles:\n")
    search_pubmed_from_term(human_species)
    print("Coronavirus Articles:\n")
    search_pubmed_from_term(corona_species)


main()