from Bio.Blast import NCBIXML

"""
Commands to create the blast database and the blast query file

Make the blast database
makeblastdb -in human_genome.fasta -dbtype nucl -out bio\fasta_files\db_folder\db_files              

Make the blast query file
blastn -query bio\fasta_files\corona_genome.fasta -db bio\fasta_files\db_folder\db_files -out corona_alignment.xml -outfmt 5 -evalue 10 -word_size 11

the e-value is specified to 10

Increasing the word size can lead to increased sensitivity (ability to detect more remote homologs) but may also increase computation time and memory usage, 
so we set the value to 11


makeblastdb -in C:\Faculdade\BioInformatica\bio\fasta_files\human_one_record_genome.fasta -dbtype nucl -out C:\Faculdade\BioInformatica\bio\fasta_files\db_folder

blastn -query C:\Faculdade\BioInformatica\bio\fasta_files\corona_genome.fasta -db C:\Faculdade\BioInformatica\bio\fasta_files\db_folder -out C:\Faculdade\BioInformatica\bio\fasta_files\one_record_corona_human.xml -outfmt 5 -evalue 10 -word_size 11

"""

def get_aligner_paraments():
   
    ## Get the blast records throw the blast file
    blast_records = NCBIXML.parse(open("fasta_files\\one_record_corona_human.xml", "r"))   

    ## Loop the records from the file
    for blast_record in blast_records:

        print("Query:", blast_record.query)
        print("Query Length:", blast_record.query_length)
        print("Number of Alignments:", len(blast_record.alignments))
        print()

        ## Get Alignements
        for alignment in blast_record.alignments:
            
            print(f"Alignment: {alignment.title}")
            print(f"  Length: {alignment.length}")

            ## High Scoring Pair (hsp) 
            ## An HSP represents a local alignment between the query sequence and a subject sequence found by the BLAST search
            for hsp in alignment.hsps:
                ## E-value represents the number of alignments that are expected to occur purely by chance when searching a sequence database of a particular size
                print(f"  E-value: {hsp.expect}")
                ## Score represents a numerical value that indicates the quality of the alignment between two sequences
                print(f"  Score: {hsp.score}")
                ## Identities refer to the number of characters (nucleotides or amino acids) in the aligned sequences that are identical
                print(f"  Identities: {hsp.identities}/{hsp.align_length}")
                print(f"  Similarity: {round(hsp.identities / hsp.align_length * 100, 3)}%")
                ## Gaps refer to the insertion or deletion of characters (nucleotides or amino acids) in one of the sequences to optimize the alignment with another sequence 
                print(f"  Gaps: {hsp.gaps}")
                print(f"  Query: {hsp.query}")
                print(f"  Match: {hsp.match}")
                print(f"  Subject: {hsp.sbjct}\n")


get_aligner_paraments()